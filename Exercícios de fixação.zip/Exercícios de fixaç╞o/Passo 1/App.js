import React from 'react';
import FormComponent from './FormComponent';
import './App.css';

function App() {
  return (
    <div className="App">
      <h1>Form with Clear Button</h1>
      <FormComponent />
    </div>
  );
}

export default App;
