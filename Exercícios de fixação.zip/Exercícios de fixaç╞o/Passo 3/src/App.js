import React from 'react';
import FactorialCalculator from './FactorialCalculator';
import './App.css';

function App() {
  return (
    <div className="App">
      <FactorialCalculator />
    </div>
  );
}

export default App;
