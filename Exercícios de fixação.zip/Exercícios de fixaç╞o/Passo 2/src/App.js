import React from 'react';
import RealTimeClock from './RealTimeClock';
import './App.css';

function App() {
  return (
    <div className="App">
      <RealTimeClock />
    </div>
  );
}

export default App;
